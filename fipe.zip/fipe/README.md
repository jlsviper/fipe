# fipe: fault-injecting protocol emulator

Entry for the Jane Street protocol emulator ASIC competition (Tiny Tapeout, IHP 130nm CMOS5L).
The architecture spec is the source of design intent; this repo implements it.

## Layout

| Path | What it is |
| --- | --- |
| `examples/` | Example programs in FIPE assembly: I2C, SPI, UART, rise time, WS2812, 1-Wire, JTAG. |
| `asm/` | Assembler and disassembler (`bin/fasm.ml` is the command-line tool). |
| `isa/` | The ISA, defined once: types, field positions, strict encode/decode. Every other part uses it. |
| `spec/` | Protocol timing specs, the single source of truth for "correct" (I2C standard mode so far). |
| `checker/` | Executor, symbolic and concrete checker, on-time cycle model, cycle-accurate simulator (`isim.ml`, handles reactive programs), monitor compiler, assembler, firmware. |
| `model/` | Device and reference models: event queue, I2C EEPROM, SPI device, UART echo device, each with realistic failure mechanisms. |
| `formal/` | Formal proofs of the timing contract (Yosys temporal induction); `tools/formal.sh` runs them, `tools/formal_mutants.sh` checks each planted bug makes a proof fail. |
| `tools/equiv.sh` | Formal equivalence: RTL against an IHP-cell gate netlist, every output proven (the `equiv` workflow). |
| `test/regress/` | Random programs and the RTL's golden output record for the gate-level regression in `test/test.py`. |
| `docs/challenge.md` | Every requirement and judging criterion from the competition, mapped to evidence. |
| `tools/cdc_check.py` | Netlist proof that every asynchronous input passes a two-flop synchronizer (runs in CI; also on post-layout netlists). |
| `bench/` | Simulated bench: a fast bus model proven against the RTL, sweep strategies, hole detection, population statistics. |
| `hw/` | Hardcaml RTL: event queue, sequencer, core, monitors, host SPI, Tiny Tapeout top. |
| `tests/` | The OCaml regression (`dune runtest`). |
| `bin/gen_verilog.ml` | Writes `src/tt_um_jlsviper_fipe.v`. `--components` also writes blocks to `build/`. |
| `src/` | Generated Verilog plus the Tiny Tapeout flow config. Do not edit the `.v` by hand. |
| `test/` | Tiny Tapeout's cocotb smoke test (also runs on the gate-level netlist). |
| `info.yaml`, `docs/info.md` | Tiny Tapeout project metadata and datasheet. |
| `.github/workflows/` | `gds` (RTL to GDS, precheck, gate-level test), `test` (cocotb), `docs`, `ocaml` (our regression). |

## Status

**Batch B (firmware only: no chip change).** Controller and target on one chip: sequencer A is an
I2C controller and sequencer B an I2C target on separate pins joined outside the chip, a real
wired-AND bus (`examples/i2c_controller_target.s`); the target receives `A0 00 5A` and
acknowledges each byte, identically on the RTL and the cycle-accurate simulator. With a
programmable acknowledge delay, the target finds the controller's sampling point (ACK up to 348
cycles, NACK from 349). SWD (`examples/swd_dpidr.s`, 57 words): line reset and a DPIDR read
against an ARM SW-DP model, with the 3-bit acknowledge decoded by branching on the pin; OK,
WAIT, FAULT and an absent port all land in their own result code, with no bus contention. The
parity bit is checked by the host (there is no XOR instruction).

**Batch A (chip change: needs a GDS run).** Timing: two slow-corner paths into the instruction
register's load are cut, with every cycle-exact test unchanged. The "caught up" flag (timebase
against schedule) is computed a cycle ahead; and the WAIT timeout compares its counter for
equality with the limit instead of magnitude (the counter starts at 0 and steps by one while
watching, so the two agree), replacing a 16-bit carry ripple with a shallow AND tree. And the
CTRL strobes are registered (start acts one cycle after the host's write): every one of the
twelve worst remaining paths ran from the SPI write data through the start decode, the fetch
address and the 64-way program memory mux into the instruction register. Routing: sequencer B fetches from the upper half of program
memory (addresses 32-63), halving its read port; `.org` places code there. Monitors: device-side
attribution, per-slot prescalers (1.3 ms to 5.4 s range), and 96 fewer configuration flip-flops;
directed tests cover same-cycle START/STOP, STOP versus ABORT, and timeout versus re-arm.
Robustness: reserved and illegal instructions trap (STATUS bit 7) instead of silently doing
nothing, and the assembler refuses reserved ones; a FRAME flag (STATUS bit 30) catches host SPI
frames that are not 40 clocks. The register map is one table (`hw/regmap.ml`, generating
`docs/registers.md`); registers in the generated Verilog carry readable names; and the
gate-level regression passes from random power-up states. Layout: OpenROAD now runs on 4 threads
(`OPENROAD_THREADS`, working around a LibreLane default bug).

**Design decision: flip-flop program memory.** The 64 x 16 program memory is built from flip-flops,
on purpose. CMOS5L is a new process with no silicon results yet: an SRAM macro there would be
unproven, and latches complicate timing and hold analysis on an uncharacterized process.
Flip-flops keep every check straightforward (the formal proofs, the RTL-to-gate equivalence and
the gate-level regression all apply unchanged), and area is not the constraint: the whole design
uses about 40% of the 6x4 tiles. An SRAM macro becomes the right choice for deep receive buffers
or programs beyond 256 words.

**Two sequencers (chip change: needs a GDS run).** A second sequencer shares the time base and
program memory (each starts at its own entry address), so concurrent programs land on one time
axis: concurrency without interleaving. Same-cycle pin conflicts resolve to A and set CONFLICT.
Full-duplex UART demonstrated (`examples/uart_full_duplex.s`): B receives each echo while A
transmits the next byte, 9.8 of 10 bits overlapping. With B idle, every earlier test passes
unchanged; 150 random concurrent program pairs match the RTL in every pin, every cycle; the core
pin proof covers both sequencers, and eight planted bugs are caught. The gate-level regression
now runs both sequencers. New registers: ENTRY (0x47), and B's PINS, STATUS, FIFO, SAMPLES and
DEBUG (0x64 to 0x6A); CTRL bit 3 starts B.

**Gate-level verification.** `tools/equiv.sh` proves the RTL equivalent to an IHP-cell gate
netlist at every output, for all inputs and all time (12,486 of 12,487 register and output
points; the last is a shift-register bit nothing reads, which synthesis deletes). The real
post-layout netlist runs a 20-program random regression (random pin roles, skews, monitor
setups, FIFO data and input waveforms) and reproduces the RTL's output record exactly; CI's
gate-level test runs it on every GDS build. `formal/README.md` explains the proofs. After
changing the chip, refresh the golden record with
`cd test && REGRESS_UPDATE=1 make COCOTB_TEST_FILTER=test_regress`.

**Formal proofs (chip change: needs a GDS run).** The timing contract is proven for all time by
temporal induction: the event queue fires every event once, in order, never early, and exactly on
time unless it flags LATE (checked against an ideal reference queue); across the whole core, a pin
changes only because an event for it fired. Seven planted bugs each make a proof fail; both run in
CI. Also: the program memory no longer has a clear (10% fewer cells), stronger antenna repair in
`src/config.json`, and `docs/challenge.md` maps every competition requirement to evidence.

**Toolchain and flexibility (chip change: needs a GDS run).** `fasm` assembles and disassembles
FIPE assembly; all 12,110 legal instruction words round-trip, and every example that documents
existing firmware assembles to its verified words exactly. Three protocols the chip was not
designed for, written only in assembly and verified against device models and the RTL: WS2812
(on-chip bit encoding, 400/800/1200 ns exactly), 1-Wire (presence via a schedule-synchronous
`jmp pin`, READ ROM with valid CRC) and JTAG (IDCODE 0x4BA00477). Chip: 16-bit X/Y loads and debug
readback registers.

**Reactive input and UART (chip change: needs a GDS run).** `WAIT` (pin condition with optional
timeout, then resynchronize the schedule) and `JMP` on pin or flag. Both stall until real time
catches up with the schedule, so every pin read happens at a data-determined time. A new
cycle-accurate simulator (`checker/isim.ml`) matches the RTL on 250 random reactive programs
against random inputs, and agrees with the executor and on-time model on 124 non-reactive ones.
`WAIT` is also checked at gate level in cocotb. UART transmit and receive work at 115,200 baud;
two sweeps (our transmit rate, our receive rate) measure a UART device's real bit period (within
0.05%) and its sample point (within 1%) from the pins alone.

**Late sampling, data-valid window, master-IP slave (chip change: status pins registered).**
`Firmware.spi_read_id_sampled` places the MISO sample anywhere in the bit. Falling-edge (late)
sampling lifts the typical part's read limit from 4.17 to 8.33 MHz. A slave that changes MISO a
fixed delay after the rising edge (built from master IP) fails falling-edge samplers at every
frequency from 2.5 MHz down, a real FTDI-cable failure. Sweeping the sample point measures the
MISO data-valid window: the master-IP slave's data changes 160 ns after the rising edge, before the
falling edge. The RTL cross-check caught a one-cycle error in the fast SPI bench (11 of 12 points
matched); fixed, now 12 of 12. uo_out[6:0] are registered to remove the worst slow-corner path.

**SPI and the synchronizer proof (chip change: needs a GDS run).** Samples read a configurable
input pin (MISO) and actions 6/7 drive an auxiliary pin (chip select): four-wire SPI. A
frequency-by-mode READ ID sweep (`tests/test_spi.ml`) against an SPI device model with
real-silicon failure modes finds a low-frequency hole (fails below 625 kHz), mode-0-only logic,
and a mode that passes only by accident. The fast SPI bench matches the RTL on 7 of 7 points.
All 18 asynchronous input bits now pass pure two-flop synchronizers; `tools/cdc_check.py` found
17 of 18 violating on the previous post-layout netlist, and 0 now.

**Timing closed (second GDS).** Setup slack at 50 MHz: +3.63 ns slow (1.08 V, 125 C), +8.64 ns
typical, +11.09 ns fast; hold met everywhere; DRC, LVS, antenna, precheck and gate-level test clean.
The registered instruction fetch moved the slow corner by 7.0 ns.

**Characterization the industry way** (`bench/`, `tests/test_characterize.ml`): a fast bus model
that reproduces the RTL exactly; a full sweep that finds non-monotonic failure holes binary search
misses; 31-part population statistics (median, robust sigma, 6-sigma limits, outliers) with the
hidden truth inside 124 of 124 measured brackets; self-characterization of our SPI port (passes
50 kHz to 8.33 MHz, guaranteed at 6.25 MHz); open-drain rise time from the pins with a two-load
method that recovers the pull-up and bus capacitance.

CI: the layout, cocotb and docs workflows run only when the chip, its tests or its metadata change;
the OCaml regression runs on every push.

**Timing closure, round 1.** First GDS: setup slack at 50 MHz +10.35 ns fast, +5.37 ns typical,
**-3.37 ns slow** (1.08 V, 125 C; 274 endpoints); hold met everywhere; LVS, DRC, antenna and
precheck clean. Reproduced exactly with OpenSTA on the post-layout netlist and SPEF. Every failing
endpoint sat behind the single-cycle instruction fetch, so the fetch is now registered
(`hw/sequencer.ml`): same cycle for every instruction, proven by the unchanged cycle-exact suite.
The lead bound is a registered flag, and due = S + (dt + K) * prescale. The next GDS run measures it.

**First GDS and review fixes.** The first RTL-to-GDS run on GitHub Actions succeeded (synthesis,
placement, routing to zero violations, DRC). The gate-level test failed only because the CMOS5L
template's `test/Makefile` never loads `sg13cmos5l_udp.v`, which defines the primitives the cell
models use; one added line fixes it, verified locally with CI's Icarus 13 build and PDK revision.
`rst_n` now passes through a two-flop synchronizer before driving the synchronous clears.

**Tiny Tapeout integration.** `hw/tt_top.ml` generates `tt_um_jlsviper_fipe` (6x4 tiles,
50 MHz): host SPI port, register map, 4-deep host FIFO, sample log, monitors behind registers.

- Full chip over its pins only (`tests/test_tt_top.ml`): SPI loads firmware and monitor
  configuration, an EEPROM on uio acknowledges, the chip logs `0001`, the device stores 0x5A.
  The monitors measure the device's own ACK edge (t_SU_DAT minimum 192 cycles).
- Verilator lint with LibreLane's exact flags: 0 errors, latches or multiple drivers.
- cocotb smoke test passes under Icarus; it also runs on the gate-level netlist in CI.
- Synthesized area: 221,520 um^2 in 13,445 cells, 24% of the 916,214 um^2 6x4 die.

**Measured datasheet (the Nov 15 gate, met in simulation).** `tests/test_sweep.ml` sweeps one
skew knob per I2C rule against `model/i2c_eeprom.ml`, a cycle-level EEPROM with realistic
failure mechanisms, and recovers every hidden device parameter from the ACK bits the chip
samples itself (29 transactions, binary search):

| Rule     | Spec      | Device needs (measured) | Hidden truth |
|----------|-----------|-------------------------|--------------|
| t_HD_STA | >= 4000 ns | 880 to 960 ns          | 900 ns       |
| t_SU_STO | >= 4000 ns | 960 to 1040 ns         | 1000 ns      |
| t_HD_DAT | >= 0 ns    | 240 to 320 ns          | 300 ns       |
| t_SU_DAT | >= 250 ns  | 80 to 160 ns           | 100 ns       |

The t_HD_DAT row flags the part as non-compliant: it needs ~300 ns of hold the spec does not
guarantee from the bus. Pass/fail uses ACK polling (`Firmware.i2c_write_and_poll`), so a missed
STOP cannot pass silently. `checker/asm.ml` is a minimal labelled assembler; the core now has
synchronized inputs and reports sampled bits.

**On-time check and timing monitors.**

- `checker/ontime.ml`: a cycle model of instruction issue and queue firing. Every RTL run
  matches it cycle for cycle, late events included: 207 on time, 36 order violations,
  and 122 stress programs where the sequencer falls behind. 0 mismatches.
- `hw/monitors.ml`: four timing-monitor slots, loaded from rules compiled out of the spec.
  `hw/loopback.ml` feeds the core's own I2C output back into them.
- Monitors vs checker: 10 skew points x 8 rules, 0 disagreements. At K = 0 the monitors
  measure every interval exactly as the checker predicts (the measured datasheet of our
  own output).
- The cross-check found a semantic gap: same-cycle edges on SDA and SCL are ambiguous
  on the wire. The checker now has a concrete mode (ground truth, hardware semantics)
  and a PATTERN validity condition on its symbolic ranges.
- Monitors area: 34,534 um^2 (twice the estimate, before config registers). Trims planned.

**Sequencer and core.** One sequencer with the enqueue stage, decoded straight from
`Isa.Field`, runs on the event queue with a timebase, program memory and pin drivers
(`hw/sequencer.ml`, `hw/core.ml`). The checker's executor is the golden model:

- The I2C firmware on the RTL fires all 91 events at exactly the predicted cycles.
- Sweeping K1, K2 across the checker's ORDER boundaries, the hardware flags agree at every
  point, on both sides of each boundary.
- 300 random programs with random skews and pins: 207 cycle-exact, 36 order violations
  predicted and flagged, 57 skipped (unbounded loops), 0 mismatches.
- Core area: 125,410 um^2, of which ~95,000 is the flip-flop program memory
  (latches planned); the sequencer is ~12,600 um^2.

**Checker v0 (spec v0.3).** The I2C master write firmware is checked against all eight
I2C standard-mode rules plus the hardware order invariant, with skews K1 (SCL) and K2 (SDA)
symbolic. Safe region: -5 <= K2 - K1 <= 5; START and STOP are the tightest rules (400 ns).
The test prints the predicted shmoo. All eight rules compile into monitor slots.

**Milestone 1.**

- ISA v0.2 encodings: 10,614 legal words; every one round-trips (checked exhaustively over all 2^16).
- Event queue (spec v0.2: committed entries, 2 fires per cycle, LATE, ORDER, window check):
  0 mismatches against the reference model over 25,000 random cycles, including runs across the
  24-bit timer wrap, with every fault class exercised.
- Synthesized area of the real queue: 17,595 um^2, 1,294 cells (IHP sg13cmos5l, typical corner).

## Setup: GitHub Codespaces (recommended)

Push this repo to GitHub, then Code > Codespaces > Create codespace on main.
`.devcontainer/setup.sh` installs the exact toolchain the code was tested with
(Ubuntu 24.04, OCaml 4.14.1, Hardcaml v0.16, yosys) and finishes by running the tests.
The first build takes about 15 to 30 minutes; after that the codespace starts in seconds.
Stop the codespace when you are done so it does not use your free hours.

## Setup: local macOS (optional)

Homebrew no longer fully supports macOS 14, so local setup may fail. If you try it,
pin the same versions as the codespace:

```sh
opam switch create fipe 4.14.2
eval $(opam env --switch=fipe)
opam install -y dune hardcaml.v0.16.0 hardcaml_waveterm.v0.16.0 \
  ppx_deriving_hardcaml.v0.16.0 ppx_jane.v0.16.0 ppx_expect.v0.16.0
```

## Everyday commands

```sh
dune build                    # compile everything
dune runtest                  # run all tests; silence means pass
dune promote                  # accept new expected output after an intended change
dune exec bin/gen_verilog.exe # regenerate src/*.v (CI fails if you forget)
dune exec bin/fasm.exe -- asm examples/uart_echo.s -o uart_echo.hex   # assemble
dune exec bin/fasm.exe -- list examples/jtag_idcode.s                 # listing
cd test && make               # Tiny Tapeout cocotb smoke test (needs iverilog + cocotb)
```

An expect test that fails prints a diff of what changed. Waveform tests print ASCII waveforms,
so a timing change shows up in code review as a picture.

## Next

1. GDS run for this batch: timing, antenna count, runtime, CDC on the post-layout netlist.
1a. Second sequencer on the shared timebase (full-duplex UART, controller plus target).
1b. FPGA bring-up with real parts (Icepi Zero); I2C at 400 kHz; export the spec into the repo.
1b. Formal proof of the timing contract; reduce hold-fix cells.
2. Device-side monitors: count an edge only while our own driver is released, so the monitors
   measure the device's outputs (ACK delay, clock stretching).
3. Area: latch-based program memory, monitor trims.
4. Read-back verification, UART and SPI firmware, formal properties.
